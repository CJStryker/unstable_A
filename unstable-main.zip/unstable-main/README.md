THIS_COMMIT: uploading the latest code from chat and captcha, am aware of the ALPHA typo in the other commit, it is written in stone sadly.

6MO ago: PM reply alpha code

Old: I am using github as a diff editor, my goal is to troubleshoot the code. (eg: np function, which somehow got completed, even though I didn't think it would be possible... surprising what a little persistence can do)
